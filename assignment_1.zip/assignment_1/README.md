# DataMining
main.py now contains part of the preprocessing, scores need to be averaged while others need to be summed depending on the type of variable.
We could also look into creating more variables we could use as features.


python main.py -m benchmark -o out_prediction.csv  -e evaluate_score.csv

python main.py -m ml -o out_prediction_ml.csv  -e evaluate_score.csv